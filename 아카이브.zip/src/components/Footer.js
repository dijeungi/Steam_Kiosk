// Footer.js

import React from 'react';

function Footer() {
  return (
    <footer>
      <p>© 2024 Steam Game Kiosk</p>
    </footer>
  );
}

export default Footer;
